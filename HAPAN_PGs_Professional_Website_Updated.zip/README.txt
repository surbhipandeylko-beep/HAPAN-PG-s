# HAPAN PG's Website

A responsive static website for HAPAN PG's, Karol Bagh, New Delhi.

## Files
- index.html — website content
- style.css — design and responsive layout

## Open locally
Double-click `index.html` or open it in a browser.

## Publish online
Upload `index.html` and `style.css` to a static hosting service. If using Google Sites, the design/content can be recreated in Google Sites, but custom HTML/CSS cannot simply be pasted into a normal Google Sites page.

## Business details used
Address: 14A/102, Ground Floor, 14 Block, WEA Karol Bagh, Channa Market, New Delhi – 110005
Double sharing: ₹14,000/month
Single room with attached washroom: ₹28,000/month
Founders: Hardik Pandey (9891749983), Surbhi Pandey (8957969568), Aashi Pandey (8707214903)
Email: surbhipandeylko@gmail.com
